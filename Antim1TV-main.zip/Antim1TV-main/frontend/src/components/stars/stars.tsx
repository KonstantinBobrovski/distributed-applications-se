import './stars.sass'
export const Stars = () => {
    return (<div id='start-container'></div>)
}