export const UserLocalStorageKey = 'SavedUser'
export const BrokenImageURL = 'https://www.publicdomainpictures.net/pictures/280000/nahled/not-found-image-15383864787lu.jpg'
export const LoadingGifURL = 'https://upload.wikimedia.org/wikipedia/commons/b/b1/Loading_icon.gif?20151024034921'
export const RickRollYoutube = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'